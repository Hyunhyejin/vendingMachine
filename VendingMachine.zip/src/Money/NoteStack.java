package Money;

public class NoteStack {
	static int account_1000 = 10;
	
	public static void addNoteMoney(int notemoney) {
			account_1000++;
	}
}
