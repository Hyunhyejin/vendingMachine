package Parents;


public interface VendingMachineStack {
	
	public void put(Object ins);
	public Object get();

}
