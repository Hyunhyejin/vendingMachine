package Parents;

public abstract class Slot {	
	public abstract void accept(int money);	
}
