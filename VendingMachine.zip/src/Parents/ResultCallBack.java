package Parents;

public interface ResultCallBack {
	void resultCallBack(String result,String msg);
}
