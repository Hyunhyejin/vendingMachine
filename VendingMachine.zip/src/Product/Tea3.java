package Product;
import Parents.Product;

public class Tea3 extends Product {

	public Tea3() {
		super();
		// TODO Auto-generated constructor stub
		this.amountOfWater = 20;
		this.productId = 1;
		this.productPrice = 500;
		this.productName = "��3";
		
	}

}
