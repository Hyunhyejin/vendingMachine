package Product;

import Parents.Product;

public class Coffee2 extends Product{

	public Coffee2() {
		super();
		// TODO Auto-generated constructor stub
		this.amountOfCoffeePowder = 5;
		this.amountOfCreamPowder = 3;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 12;
		this.productId = 2;
		this.productPrice = 400;
		this.productName = "Ŀ��2";
	}

	
}
