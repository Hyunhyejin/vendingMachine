package Product;
import Parents.Product;

public class Coffee1 extends Product {

	public Coffee1() {
		super();
		// TODO Auto-generated constructor stub
		this.amountOfCoffeePowder = 3;
		this.amountOfCreamPowder = 3;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 10;
		this.productId = 1;
		this.productPrice = 300;
		this.productName = "Ŀ��1";
	}

}
