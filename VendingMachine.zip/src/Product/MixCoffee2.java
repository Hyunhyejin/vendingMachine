package Product;

import Parents.Product;

public class MixCoffee2 extends Product{

	public MixCoffee2() {
		super();
		// TODO Auto-generated constructor stub
		
		this.amountOfCoffeePowder = 5;
		this.amountOfCreamPowder = 7;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 12;
		this.productId = 5;
		this.productPrice = 400;
		this.productName = "�ͽ�Ŀ��2";
		
	}
	
	

}
