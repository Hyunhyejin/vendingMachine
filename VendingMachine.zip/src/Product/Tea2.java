package Product;
import Parents.Product;

public class Tea2 extends Product {

	public Tea2() {
		super();
		// TODO Auto-generated constructor stub
		this.amountOfWater = 30;
		this.productId = 1;
		this.productPrice = 400;
		this.productName = "��2";
		
	}

}
