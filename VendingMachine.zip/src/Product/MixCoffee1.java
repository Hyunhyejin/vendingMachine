package Product;

import Parents.Product;

public class MixCoffee1 extends Product {

	public MixCoffee1() {
		super();
		// TODO Auto-generated constructor stub
		
		this.amountOfCoffeePowder = 5;
		this.amountOfCreamPowder = 5;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 12;
		this.productId = 4;
		this.productPrice = 300;
		this.productName = "�ͽ�Ŀ��1";
		
	}

}
