package Product;

import Parents.Product;

public class Coffee3 extends Product {

	public Coffee3() {
		super();
		// TODO Auto-generated constructor stub
		
		this.amountOfCoffeePowder = 7;
		this.amountOfCreamPowder = 3;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 14;
		this.productId = 3;
		this.productPrice = 500;
		this.productName = "Ŀ��3";
		
	}

	
}
