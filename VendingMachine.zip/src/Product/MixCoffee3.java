package Product;

import Parents.Product;

public class MixCoffee3 extends Product{

	public MixCoffee3() {
		super();
		// TODO Auto-generated constructor stub
		
		this.amountOfCoffeePowder = 5;
		this.amountOfCreamPowder = 9;
		this.amountOfSugarPowder = 3;
		this.amountOfWater = 12;
		this.productId = 6;
		this.productPrice = 500;
		this.productName = "�ͽ�Ŀ��3";
	}
	
	

}
