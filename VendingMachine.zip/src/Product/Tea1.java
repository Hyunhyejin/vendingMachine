package Product;
import Parents.Product;

public class Tea1 extends Product {

	public Tea1() {
		super();
		// TODO Auto-generated constructor stub
		this.amountOfWater = 20;
		this.productId = 1;
		this.productPrice = 300;
		this.productName = "��1";
		
	}

}
