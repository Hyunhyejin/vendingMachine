import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import MakingSystem.StockManager;

public class AdminPage extends JFrame implements ActionListener {
	
	StockManager stock = new StockManager();
	
	// JPanel ����
	JPanel west = new JPanel();
	JPanel east = new JPanel();
	JPanel north = new JPanel();
	
	// JLabel ���� (��, Ŀ��, ����, ���� ����)
	JLabel lblCoffee = new JLabel("Ŀ�� ���");
	JLabel lblPowder1 = new JLabel("ũ�� �Ŀ�� ���");
	JLabel lblPowder2 = new JLabel("���� �Ŀ�� ���");
	JLabel lblWater = new JLabel("���� �� ��");
	JLabel lblCoin = new JLabel("�ܵ� ��");
	JLabel lblCup = new JLabel ("�� ����");
	JLabel lblTitle = new JLabel("Admin Page");
	
	// JTextField ����
	JTextField stockCoffee = new JTextField(20);
	JTextField stockCreamPowder = new JTextField(20);
	JTextField stockSugarPowder = new JTextField(20);
	JTextField stockWater = new JTextField(20);
	JTextField stockCoin = new JTextField(20);
	JTextField stockCup = new JTextField(20);
	
	// ���� �г�
	JPanel south =  new JPanel();
	JButton btnExit = new JButton("������ ��� ����");
	JButton btnApply = new JButton("��� ����");
	JButton btnReset = new JButton("�ʱ�ȭ");
	
	public AdminPage() {
		
		north.add(lblTitle);
		lblTitle.setFont(new Font(Font.SANS_SERIF, Font.PLAIN|Font.BOLD, 16));
		lblTitle.setBorder(new EmptyBorder(10, 10, 10, 10));
		add("North", north);
		
		west.setLayout(new GridLayout(5,1,10,10));
		west.setBorder(new EmptyBorder(0, 10, 0, 0));
		west.add(lblCoffee);
		west.add(lblPowder1);
		west.add(lblPowder2);
		west.add(lblWater);
		west.add(lblCup);
		add("West", west);
		
		east.setLayout(new GridLayout(5,1,10,10));
		east.setBorder(new EmptyBorder(0, 30, 0, 50));
		east.add(stockCoffee);
		east.add(stockCreamPowder);
		east.add(stockSugarPowder);
		east.add(stockWater);
		east.add(stockCup);
		add("Center", east);
		
		south.setLayout(new FlowLayout());
		south.setBorder(new EmptyBorder(10, 0, 10, 0));
		south.add(btnApply);
		south.add(btnReset);
		south.add(btnExit);
		add("South", south);
		
		int tmpCoffee = stock.getAmount_coffee_powder();
		String tmpC = Integer.toString(tmpCoffee);
		stockCoffee.setText(tmpC);
		
		int tmpCream = stock.getAmount_cream_powder();
		String tmpCr = Integer.toString(tmpCream);
		stockCreamPowder.setText(tmpCr);
		
		int tmpSugar = stock.getAmount_sugar_powder();
		String tmpS = Integer.toString(tmpSugar);
		stockSugarPowder.setText(tmpS);
		
		int tmpWater = stock.getAmount_water();
		String tmpW = Integer.toString(tmpWater);
		stockWater.setText(tmpW);
		
		int tmpCup = stock.getAmount_cup();
		String tmpCu = Integer.toString(tmpCup);
		stockCup.setText(tmpCu);
		
		setSize(600, 300);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		eventHandler();
	}
	
	public void eventHandler() {
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);	
			}	
		});
		
		btnExit.addActionListener(this);
		btnApply.addActionListener(this);
		btnReset.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent a) {
		Object obj = a.getSource();
		
		if (obj == btnExit) exitWindow();
		if (obj == btnApply) applySetting();
		if (obj == btnReset) resetSetting();
		
	}
	
	public void exitWindow() {
		System.exit(0);
	}
	
	public void applySetting() {
		String Ct = stockCoffee.getText();
		int Coffeetmp = Integer.parseInt(Ct);
		stock.setAmount_coffee_powder(Coffeetmp);
		
		String Crt = stockCreamPowder.getText();
		int CreamPowdertmp = Integer.parseInt(Crt);
		stock.setAmount_cream_powder(CreamPowdertmp);
		
		String St = stockSugarPowder.getText();
		int SugarPowdertmp = Integer.parseInt(St);
		stock.setAmount_sugar_powder(SugarPowdertmp);
		
		String Cupt = stockCup.getText();
		int Cuptmp = Integer.parseInt(Cupt);
		stock.setAmount_cup(Cuptmp);
		
		String Watert = stockWater.getText();
		int Watertmp = Integer.parseInt(Watert);
		stock.setAmount_water(Watertmp);
		
	}
	
	public void resetSetting() {
		int tmpCoffee = stock.getAmount_coffee_powder();
		String tmpC = Integer.toString(tmpCoffee);
		stockCoffee.setText(tmpC);
		
		int tmpCream = stock.getAmount_cream_powder();
		String tmpCr = Integer.toString(tmpCream);
		stockCreamPowder.setText(tmpCr);
		
		int tmpSugar = stock.getAmount_sugar_powder();
		String tmpS = Integer.toString(tmpSugar);
		stockSugarPowder.setText(tmpS);
		
		int tmpWater = stock.getAmount_water();
		String tmpW = Integer.toString(tmpWater);
		stockWater.setText(tmpW);
		
		int tmpCup = stock.getAmount_cup();
		String tmpCu = Integer.toString(tmpCup);
		stockCup.setText(tmpCu);
	}
	
	public static void main (String[] args) {
		new AdminPage();
	}
	
}